<?php
$flag = 'Syc{dog_dog_dog_dog}';
?>
